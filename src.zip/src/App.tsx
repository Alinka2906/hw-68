import React from 'react';
import {Route, Routes} from 'react-router-dom';
import TaskEdit from './containers/TaskForm/TaskEdit';
import Layout from './components/Layout/Layout';
import Tasks from './containers/Tasks/Tasks';

function App() {
  return (
    <Layout>
      <Routes>
        <Route path='/' element={(<Tasks/>)}>
        </Route>
        <Route path='/edit-task/:id' element={(<TaskEdit/>)}>
        </Route>
      </Routes>
    </Layout>
  );
}

export default App;

