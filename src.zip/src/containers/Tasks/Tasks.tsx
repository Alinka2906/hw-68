import React, {useEffect} from 'react';
import {fetchTasks} from './tasksThunks';
import {useAppDispatch, useAppSelector} from '../../app/hooks';
import Spinner from '../../components/Spinner/Spinner';
import TaskItem from './TaskItem';
import axiosApi from '../../axiosApi';
import TasksNew from '../TaskForm/TaskNew';


const Tasks: React.FC = () => {
  const dispatch = useAppDispatch();
  const tasks = useAppSelector(state => state.tasks.items);
  const loadingState = useAppSelector(state => state.tasks.fetchLoading);

  const deleteTask = async (id: string) => {
    if (window.confirm('Do you really want to delete this task?')) {
      await axiosApi.delete('/tasks/' + id + '.json');
      await dispatch(fetchTasks());
    }
  };

  useEffect(() => {
    dispatch(fetchTasks())
  }, [dispatch])

  return (
    <div>
      <div>
        <TasksNew/>
      </div>
      <div className='d-flex flex-wrap justify-content-around'>
      {loadingState === 'pending' ? <Spinner/> : tasks.map(task => (
              <TaskItem
                key={task.id}
                task={task}
                onDelete={() => deleteTask(task.id)}
              />
            ))}
              </div>
          </div>
  );
};

export default Tasks;